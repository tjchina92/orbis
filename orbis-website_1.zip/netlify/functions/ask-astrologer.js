// 오르비스 "AI에게 물어보기" 기능의 서버리스 프록시 함수.
//
// 이 함수가 필요한 이유: 브라우저(index.html)에서 곧바로 Anthropic API를 호출하면
// API 키가 모든 방문자에게 노출돼요. 그래서 브라우저는 이 함수만 호출하고,
// 이 함수가 서버 쪽 환경변수에만 보관된 키로 Anthropic API를 대신 호출해줘요.
//
// 배포 전 꼭 해야 할 일 (Netlify 사이트 설정 -> Environment variables):
//   ANTHROPIC_API_KEY   (필수) console.anthropic.com 에서 발급받은 키
//   ANTHROPIC_MODEL     (선택) 기본값은 아래 DEFAULT_MODEL. 다른 모델을 쓰고 싶으면 설정.
//
// 절대로 이 파일이나 프론트엔드 코드에 실제 API 키 값을 적지 마세요.

var DEFAULT_MODEL = "claude-haiku-4-5-20251001"; // 저렴하고 빠른 모델 -- 질문 하나당 비용을 낮게 유지하려는 목적
var MAX_QUESTION_LEN = 400;
var MAX_CONTEXT_LEN = 4000;
var MAX_OUTPUT_TOKENS = 700;

var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8"
};

function respond(statusCode, bodyObj) {
  return { statusCode: statusCode, headers: CORS_HEADERS, body: JSON.stringify(bodyObj) };
}

exports.handler = async function (event) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return respond(405, { error: "POST 요청만 지원해요." });
  }

  var apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    // 배포는 됐지만 환경변수를 아직 안 넣은 흔한 실수 -- 프론트엔드에 그대로 안내 문구로 노출된다.
    return respond(500, { error: "서버에 ANTHROPIC_API_KEY 환경변수가 설정되지 않았어요. Netlify 사이트 설정에서 추가해주세요." });
  }

  var payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch (e) {
    return respond(400, { error: "요청 형식이 올바르지 않아요." });
  }

  var question = String(payload.question || "").trim();
  var chartContext = String(payload.chartContext || "").trim();

  if (!question) return respond(400, { error: "질문을 입력해주세요." });
  if (question.length > MAX_QUESTION_LEN) {
    return respond(400, { error: "질문은 " + MAX_QUESTION_LEN + "자 이내로 적어주세요." });
  }
  if (chartContext.length > MAX_CONTEXT_LEN) chartContext = chartContext.slice(0, MAX_CONTEXT_LEN);

  var systemPrompt =
    "당신은 '오르비스'라는 서양 점성술 앱 안에 있는 다정하고 신뢰감 있는 점성술 해설가입니다. " +
    "아래에 사용자의 실제 탄생차트 데이터(천체 위치, 하우스, 어스펙트 등)가 주어집니다. " +
    "이 데이터를 근거로 사용자의 질문에 한국어로, 친절하고 구체적으로, 3~5문단을 넘지 않게 답하세요. " +
    "점성술은 통계적으로 검증된 과학이 아니라 자기 성찰을 위한 상징 체계라는 점을 은근히 전제하고, " +
    "특정 사건을 확정적으로 예언하거나 의학적·법적·재정적 조언을 하지 마세요. " +
    "데이터에 없는 천체나 하우스는 지어내지 말고, 필요한 정보가 없으면 없다고 답하세요.\n\n" +
    "[사용자의 탄생차트 데이터]\n" + (chartContext || "(차트 정보가 전달되지 않았어요. 일반적인 점성술 지식으로 답해주세요.)");

  try {
    var upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || DEFAULT_MODEL,
        max_tokens: MAX_OUTPUT_TOKENS,
        system: systemPrompt,
        messages: [{ role: "user", content: question }]
      })
    });

    var data = await upstream.json();

    if (!upstream.ok) {
      var upstreamMsg = (data && data.error && data.error.message) || ("Anthropic API 오류 (" + upstream.status + ")");
      return respond(upstream.status >= 400 && upstream.status < 500 ? 502 : 502, { error: upstreamMsg });
    }

    var answer = (data.content && data.content[0] && data.content[0].text) || "";
    if (!answer) return respond(502, { error: "AI로부터 빈 응답을 받았어요." });

    return respond(200, { answer: answer });
  } catch (e) {
    return respond(502, { error: "AI 서비스 호출 중 오류가 발생했어요: " + e.message });
  }
};
